import React from 'react'
import { Link } from 'gatsby'

const Header = ({ siteTitle }) => (
  <div>
    <Link to="/">Logo</Link>
    <Link to="/whatwedo/">WhatWeDo</Link>
    <Link to="/cases">Cases</Link>
    <Link to="/contact">Contact</Link>
  </div>
)

export default Header
