module.exports = [{
      plugin: require('/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/node_modules/gatsby-plugin-offline/gatsby-browser'),
      options: {"plugins":[]},
    },{
      plugin: require('/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/gatsby-browser.js'),
      options: {"plugins":[]},
    }]
