// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---cache-dev-404-page-js": () => import("/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/.cache/dev-404-page.js" /* webpackChunkName: "component---cache-dev-404-page-js" */),
  "component---src-pages-404-js": () => import("/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/src/pages/404.js" /* webpackChunkName: "component---src-pages-404-js" */),
  "component---src-pages-contact-js": () => import("/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/src/pages/contact.js" /* webpackChunkName: "component---src-pages-contact-js" */),
  "component---src-pages-index-js": () => import("/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/src/pages/index.js" /* webpackChunkName: "component---src-pages-index-js" */),
  "component---src-pages-whatwedo-js": () => import("/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/src/pages/whatwedo.js" /* webpackChunkName: "component---src-pages-whatwedo-js" */),
  "component---src-pages-cases-js": () => import("/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/src/pages/cases.js" /* webpackChunkName: "component---src-pages-cases-js" */)
}

exports.data = () => import("/Users/past7/Code/GatsbyJs/gatsby-starter-lightbox/.cache/data.json")

